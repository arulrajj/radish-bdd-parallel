/**
 * Artifacts Module
 * Barrel export for artifacts service
 */

export * from './ArtifactsService';
