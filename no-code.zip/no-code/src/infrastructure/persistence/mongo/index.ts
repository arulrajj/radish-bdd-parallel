/**
 * MongoDB Persistence Module
 * Barrel export for MongoDB infrastructure
 */

export * from './MongoConnection';
export * from './BaseRepository';
