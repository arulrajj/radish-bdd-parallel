/**
 * Dashboard Page Index
 */

export { Dashboard, default } from './Dashboard';
