/**
 * Editor Page Index
 */

export { Editor, default } from './Editor';
