/**
 * History Page Index
 */

export { History, default } from './History';
