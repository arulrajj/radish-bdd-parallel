/**
 * Results Page Index
 */

export { Results, default } from './Results';
