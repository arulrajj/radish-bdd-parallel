/**
 * Settings Page Index
 */

export { Settings, default } from './Settings';
